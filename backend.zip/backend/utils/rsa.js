import { readFileSync } from 'fs';
import { privateDecrypt, constants } from 'crypto';
import { execSync } from 'child_process';
import { config } from '../config.js';

const privateKey = readFileSync(config.rsa.privateKeyPath, 'utf8');

export function decryptRSA(encryptedBase64) {
  try {
    const buffer = Buffer.from(encryptedBase64, "base64");
    const decrypted = privateDecrypt(
      {
        key: privateKey,
        padding: constants.RSA_PKCS1_PADDING,
      },
      buffer
    );
    return decrypted.toString("utf8");
  } catch (err) {
    console.error("Node.js RSA decryption failed. Trying OpenSSL...");
    try {
      const result = execSync(`echo "${encryptedBase64}" | openssl rsautl -decrypt -inkey ${config.rsa.privateKeyPath} -keyform PEM -pkcs`);
      return result.toString("utf8");
    } catch (e) {
      throw new Error("Decryption failed using both Node.js and OpenSSL.");
    }
  }
}
