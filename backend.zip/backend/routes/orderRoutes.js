import express from "express";
import { placeOrder, getPendingOrders, getCompletedOrders } from "../controllers/orderController.js";

const router = express.Router();

router.post("/order", (req, res) => {
  console.log("✅ /api/order hit");
  res.json({ message: "It worked!" });
});

router.get("/pending", getPendingOrders);
router.get("/completed", getCompletedOrders);

export default router;
