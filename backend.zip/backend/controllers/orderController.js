import { pool } from "../models/db.js";
import { decryptRSA } from "../utils/rsa.js";

export const placeOrder = async (req, res) => {
  try {
    // Comment these lines
// const encrypted = req.body.encryptedData;
// const decrypted = JSON.parse(decryptRSA(encrypted));

// Replace with:
const decrypted = req.body;

    const { type, qty, price } = decrypted;

    const connection = await pool.getConnection();
    await connection.beginTransaction();

    let remainingQty = qty;

    if (type === "buyer") {
      const [sellers] = await connection.query(
        `SELECT * FROM pending_orders WHERE type='seller' AND price <= ? ORDER BY price ASC FOR UPDATE`,
        [price]
      );

      for (const seller of sellers) {
        if (remainingQty <= 0) break;
        const matchedQty = Math.min(remainingQty, seller.qty);

        await connection.query(`INSERT INTO completed_orders (price, qty) VALUES (?, ?)`, [seller.price, matchedQty]);

        if (matchedQty === seller.qty) {
          await connection.query(`DELETE FROM pending_orders WHERE id = ?`, [seller.id]);
        } else {
          await connection.query(`UPDATE pending_orders SET qty = ? WHERE id = ?`, [seller.qty - matchedQty, seller.id]);
        }

        remainingQty -= matchedQty;
      }

      if (remainingQty > 0) {
        await connection.query(`INSERT INTO pending_orders (type, qty, price) VALUES ('buyer', ?, ?)`, [remainingQty, price]);
      }
    } else if (type === "seller") {
      const [buyers] = await connection.query(
        `SELECT * FROM pending_orders WHERE type='buyer' AND price >= ? ORDER BY price DESC FOR UPDATE`,
        [price]
      );

      for (const buyer of buyers) {
        if (remainingQty <= 0) break;
        const matchedQty = Math.min(remainingQty, buyer.qty);

        await connection.query(`INSERT INTO completed_orders (price, qty) VALUES (?, ?)`, [buyer.price, matchedQty]);

        if (matchedQty === buyer.qty) {
          await connection.query(`DELETE FROM pending_orders WHERE id = ?`, [buyer.id]);
        } else {
          await connection.query(`UPDATE pending_orders SET qty = ? WHERE id = ?`, [buyer.qty - matchedQty, buyer.id]);
        }

        remainingQty -= matchedQty;
      }

      if (remainingQty > 0) {
        await connection.query(`INSERT INTO pending_orders (type, qty, price) VALUES ('seller', ?, ?)`, [remainingQty, price]);
      }
    }

    await connection.commit();
    connection.release();
    res.json({ success: true, message: "Order processed" });

  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: err.message });
  }
};

export const getPendingOrders = async (req, res) => {
  const [rows] = await pool.query(`SELECT * FROM pending_orders ORDER BY created_at ASC`);
  res.json(rows);
};

export const getCompletedOrders = async (req, res) => {
  const [rows] = await pool.query(`SELECT * FROM completed_orders ORDER BY created_at DESC`);
  res.json(rows);
};
